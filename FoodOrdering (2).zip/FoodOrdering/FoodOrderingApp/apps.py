from django.apps import AppConfig


class FoodorderingappConfig(AppConfig):
    name = 'FoodOrderingApp'
